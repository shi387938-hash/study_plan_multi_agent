#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
多Agent协同学习/备考计划定制系统
基于AutoGen实现的多智能体协作系统，支持：
1. 学情分析：自动分析用户当前学习状态
2. 计划生成：根据学情生成个性化学习计划
2. 进度跟踪：跟踪每日学习进度，识别薄弱环节
4. 动态调整：根据进度自动优化后续学习计划
"""

import os
import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional

import autogen
from autogen import ConversableAgent, GroupChat, GroupChatManager

# ==================== 配置区域 ====================
# 大模型配置 (可替换为豆包/通义千问/Ollama等兼容OpenAI接口的模型)
LLM_CONFIG = {
    "config_list": [
        {
            "model": "gpt-3.5-turbo",  # 可替换为其他模型，如 "qwen-max"
            "api_key": os.getenv("OPENAI_API_KEY", "your_api_key_here"),
            "base_url": os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1"),  # 本地模型可改为 http://localhost:11434/v1
        }
    ],
    "temperature": 0.7,
    "timeout": 120,
}

# 数据存储文件
DATA_FILE = "study_plan_data.json"

# ==================== 数据存储模块 ====================
class DataStorage:
    """简单的本地数据存储，用于保存用户学情、计划和进度"""
    
    @staticmethod
    def load_data() -> Dict:
        """加载用户数据"""
        if os.path.exists(DATA_FILE):
            with open(DATA_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {}
    
    @staticmethod
    def save_data(data: Dict):
        """保存用户数据"""
        with open(DATA_FILE, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    
    @staticmethod
    def update_user_data(user_id: str, key: str, value: any):
        """更新用户的特定数据字段"""
        data = DataStorage.load_data()
        if user_id not in data:
            data[user_id] = {}
        data[user_id][key] = value
        DataStorage.save_data(data)

# ==================== Agent 定义 ====================
def create_agents(user_id: str):
    """创建所有协作Agent"""
    
    # 1. 学情分析Agent
    analysis_agent = ConversableAgent(
        name="学情分析专家",
        system_message="""你是专业的学情分析专家，擅长根据用户输入的信息生成精准的学情画像。
你的任务是：
1. 分析用户的当前成绩、薄弱科目、可用时间、考试目标
2. 识别用户的知识短板和学习潜力
3. 生成结构化的学情画像，包含：基础水平评估、薄弱环节、时间利用率评估
4. 输出格式要清晰，便于后续Agent使用

请用中文回复，保持专业但易懂的语气。
        """,
        llm_config=LLM_CONFIG,
        human_input_mode="NEVER",
    )
    
    # 2. 计划生成Agent
    planner_agent = ConversableAgent(
        name="学习计划规划师",
        system_message="""你是资深的学习计划规划师，擅长根据学情画像生成科学的个性化学习计划。
你的任务是：
1. 基于学情分析的结果，结合考试大纲要求
2. 将整个备考周期划分为：基础阶段、强化阶段、冲刺阶段
3. 为每个阶段分配合理的科目学习时间，重点向薄弱科目倾斜
4. 生成每日可执行的学习任务，包含具体的学习内容和预期时长
5. 确保计划符合用户的每日可用时间，不会过载

请输出结构化的学习计划，分阶段展示，每个任务要具体可执行。
        """,
        llm_config=LLM_CONFIG,
        human_input_mode="NEVER",
    )
    
    # 3. 进度跟踪Agent
    tracker_agent = ConversableAgent(
        name="进度跟踪分析师",
        system_message="""你是学习进度跟踪分析师，负责跟踪用户的每日学习进度并评估效果。
你的任务是：
1. 分析用户的每日打卡数据：学习内容、时长、测试结果
2. 对比原计划，评估用户的完成情况
3. 识别用户的薄弱知识点和进步情况
4. 生成进度复盘报告，指出哪些环节做得好，哪些需要改进

请用数据说话，客观评估学习效果。
        """,
        llm_config=LLM_CONFIG,
        human_input_mode="NEVER",
    )
    
    # 4. 计划调整Agent
    adjuster_agent = ConversableAgent(
        name="计划动态调整师",
        system_message="""你是计划动态调整师，擅长根据进度反馈优化学习计划。
你的任务是：
1. 基于进度跟踪的结果，分析原计划的合理性
2. 如果用户进度超前，适当增加难度或提前进入下一阶段
3. 如果用户进度滞后或某科目薄弱，调整时间分配，增加薄弱科目的学习时间
4. 如果用户某科目进步明显，可以适当减少该科目的时间，分配给其他科目
5. 确保调整后的计划依然科学合理，符合用户的实际情况

请输出调整后的完整学习计划，说明调整的原因。
        """,
        llm_config=LLM_CONFIG,
        human_input_mode="NEVER",
    )
    
    # 用户代理（模拟用户交互）
    user_proxy = ConversableAgent(
        name="用户",
        llm_config=False,
        human_input_mode="ALWAYS",
        code_execution_config=False,
    )
    
    return {
        "user": user_proxy,
        "analysis": analysis_agent,
        "planner": planner_agent,
        "tracker": tracker_agent,
        "adjuster": adjuster_agent
    }

# ==================== 核心功能 ====================
def create_study_plan(user_id: str):
    """创建新的学习计划"""
    print("\n" + "="*50)
    print("📚 新建个性化学习计划")
    print("="*50)
    
    # 收集用户输入
    print("\n请输入你的备考信息：")
    exam_name = input("考试名称（如：考研英语、四六级、CPA）: ")
    days_left = int(input("距离考试还有多少天？: "))
    daily_time = float(input("你每天可用的学习时间是多少小时？: "))
    
    print("\n请输入你当前的各科成绩（输入q结束）：")
    subjects = {}
    while True:
        subject = input("科目名称: ")
        if subject.lower() == 'q':
            break
        score = float(input(f"{subject}当前成绩: "))
        target_score = float(input(f"{subject}目标成绩: "))
        subjects[subject] = {
            "current": score,
            "target": target_score
        }
    
    if not subjects:
        print("错误：至少需要输入一个科目！")
        return
    
    # 整理输入信息
    user_input = f"""
考试信息：
- 考试名称：{exam_name}
- 剩余时间：{days_left}天
- 每日可用学习时间：{daily_time}小时

各科情况：
"""
    for subj, info in subjects.items():
        user_input += f"- {subj}: 当前成绩{info['current']}, 目标成绩{info['target']}\n"
    
    # 创建Agent
    agents = create_agents(user_id)
    
    # 创建GroupChat
    groupchat = GroupChat(
        agents=[agents["user"], agents["analysis"], agents["planner"]],
        messages=[],
        max_round=5
    )
    manager = GroupChatManager(groupchat=groupchat, llm_config=LLM_CONFIG)
    
    # 启动协作
    print("\n🤖 多Agent正在协作生成你的学习计划...")
    agents["user"].initiate_chat(
        manager,
        message=f"请根据以下用户信息，先进行学情分析，然后生成个性化学习计划：{user_input}"
    )
    
    # 保存结果
    plan_result = groupchat.messages[-1]["content"]
    DataStorage.update_user_data(user_id, "study_plan", {
        "exam_name": exam_name,
        "days_left": days_left,
        "daily_time": daily_time,
        "subjects": subjects,
        "plan": plan_result,
        "created_at": datetime.now().isoformat()
    })
    
    print("\n✅ 学习计划已生成并保存！")

def daily_checkin(user_id: str):
    """每日学习打卡"""
    data = DataStorage.load_data().get(user_id, {})
    if not data.get("study_plan"):
        print("❌ 你还没有创建学习计划，请先创建计划！")
        return
    
    print("\n" + "="*50)
    print("📝 每日学习打卡")
    print("="*50)
    
    # 收集打卡信息
    print("\n请输入今日学习情况：")
    date = input("日期（默认今天）: ") or datetime.now().strftime("%Y-%m-%d")
    
    print("\n请输入今日各科学习情况（输入q结束）：")
    daily_progress = {}
    total_study_time = 0
    while True:
        subject = input("科目名称: ")
        if subject.lower() == 'q':
            break
        study_time = float(input(f"今日学习{subject}多长时间（小时）？: "))
        task_content = input("今日学习了什么内容？: ")
        test_score = input("今日测试成绩/正确率（如有）: ")
        
        daily_progress[subject] = {
            "time": study_time,
            "content": task_content,
            "test_score": test_score
        }
        total_study_time += study_time
    
    if not daily_progress:
        print("错误：至少需要输入一个科目的学习情况！")
        return
    
    # 整理打卡信息
    checkin_input = f"""
今日打卡信息：
- 日期：{date}
- 总学习时长：{total_study_time}小时

今日学习详情：
"""
    for subj, info in daily_progress.items():
        checkin_input += f"- {subj}: 学习{info['time']}小时，内容：{info['content']}，测试：{info['test_score']}\n"
    
    checkin_input += f"\n原学习计划：{data['study_plan']['plan']}"
    
    # 创建Agent
    agents = create_agents(user_id)
    
    # 创建GroupChat
    groupchat = GroupChat(
        agents=[agents["user"], agents["tracker"], agents["adjuster"]],
        messages=[],
        max_round=4
    )
    manager = GroupChatManager(groupchat=groupchat, llm_config=LLM_CONFIG)
    
    # 启动协作
    print("\n🤖 Agent正在分析你的学习进度并调整计划...")
    agents["user"].initiate_chat(
        manager,
        message=f"请根据以下今日打卡信息，先进行进度复盘，然后根据复盘结果动态调整后续学习计划：{checkin_input}"
    )
    
    # 保存打卡记录和新计划
    new_plan = groupchat.messages[-1]["content"]
    
    # 更新数据
    checkins = data.get("checkins", {})
    checkins[date] = daily_progress
    
    DataStorage.update_user_data(user_id, "checkins", checkins)
    DataStorage.update_user_data(user_id, "study_plan.plan", new_plan)
    
    print("\n✅ 打卡完成！计划已根据你的进度自动调整！")

def view_progress(user_id: str):
    """查看学习进度"""
    data = DataStorage.load_data().get(user_id, {})
    if not data:
        print("❌ 暂无数据，请先创建学习计划！")
        return
    
    print("\n" + "="*50)
    print("📊 学习进度总览")
    print("="*50)
    
    if data.get("study_plan"):
        plan = data["study_plan"]
        print(f"\n📋 当前计划：{plan['exam_name']}")
        print(f"   剩余时间：{plan['days_left']}天")
        print(f"   每日目标学习时间：{plan['daily_time']}小时")
    
    checkins = data.get("checkins", {})
    if checkins:
        print(f"\n📅 已打卡天数：{len(checkins)}天")
        total_time = 0
        for date, progress in checkins.items():
            day_time = sum(v['time'] for v in progress.values())
            total_time += day_time
            print(f"   {date}: 学习{day_time}小时")
        
        print(f"\n⏱️ 累计学习时长：{total_time:.1f}小时")
        print(f"📈 平均每日学习：{total_time/len(checkins):.1f}小时")
    else:
        print("\n暂无打卡记录，快去打卡吧！")

def main():
    """主函数"""
    print("="*60)
    print("🎯 多Agent协同学习/备考计划定制系统")
    print("="*60)
    print("\n这是一个基于多智能体协作的个性化学习助手，能够：")
    print("  ✅ 智能分析你的学情状态")
    print("  ✅ 生成科学的个性化学习计划")
    print("  ✅ 跟踪每日学习进度")
    print("  ✅ 动态调整优化学习计划")
    print()
    
    # 默认用户ID（可扩展为多用户）
    user_id = "default_user"
    
    while True:
        print("\n" + "-"*40)
        print("请选择功能：")
        print("1. 创建新的学习计划")
        print("2. 每日学习打卡")
        print("3. 查看学习进度")
        print("4. 退出")
        
        choice = input("\n输入选项编号: ")
        
        if choice == "1":
            create_study_plan(user_id)
        elif choice == "2":
            daily_checkin(user_id)
        elif choice == "3":
            view_progress(user_id)
        elif choice == "4":
            print("\n👋 再见！祝你学习顺利！")
            break
        else:
            print("❌ 无效的选项，请重新输入！")

if __name__ == "__main__":
    # 检查环境变量
    if not os.getenv("OPENAI_API_KEY"):
        print("⚠️  提醒：请先设置 OPENAI_API_KEY 环境变量，")
        print("   或者在代码中的 LLM_CONFIG 里填写你的API密钥。")
        print("   你也可以使用本地Ollama模型，只需修改base_url为 http://localhost:11434/v1")
        print()
    
    main()
